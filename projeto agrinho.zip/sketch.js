let temperatura = 20; // Temperatura inicial
let arvoresPlantadas = 0; // Contador de árvores
let jardineiro; // Posição do jardineiro
let gameOver = false; // Flag para verificar se o jogo acabou
let trees = []; // Array para armazenar as posições das árvores

function setup() {
    createCanvas(800, 600);
    jardineiro = createVector(width / 2, height - 50); // Posição inicial do jardineiro
}

function draw() {
    background(135, 206, 235); // Céu azul
    fill(34, 139, 34); // Cor das árvores
    textSize(24);
    text("Árvores Plantadas: " + arvoresPlantadas, 10, 30);
    text("Temperatura: " + temperatura + "°C", 10, 60);

    // Desenha as árvores plantadas
    for (let i = 0; i < trees.length; i++) {
        fill(139, 69, 19); // Cor do tronco
        rect(trees[i].x, trees[i].y, 20, 40); // Tronco da árvore
        fill(0, 128, 0); // Cor das folhas
        ellipse(trees[i].x + 10, trees[i].y - 10, 40, 40); // Folhas da árvore
    }

    // Verifica se o jogo acabou
    if (temperatura > 30) {
        fill(255, 0, 0);
        textSize(32);
        text("Você perdeu! A temperatura está muito alta!", width / 2 - 300, height / 2);
        noLoop(); // Para o jogo
        gameOver = true;
    } else if (arvoresPlantadas >= 10) {
        fill(0, 138, 0);
        textSize(32);
        text("Você venceu! Você plantou muitas árvores!", width / 4 - 100, height / 5);
        noLoop(); // Para o jogo
        gameOver = true;
    }

    // Desenha o jardineiro
    fill(255, 215, 0); // Cor do jardineiro
    rect(jardineiro.x, jardineiro.y, 50, 50); // Representação do jardineiro
}

function keyPressed() {
    if (!gameOver) {
        if (keyCode === LEFT_ARROW) {
            jardineiro.x -= 15; // Move para a esquerda
        } else if (keyCode === RIGHT_ARROW) {
            jardineiro.x += 15; // Move para a direita
        } else if (key === 'p' || key === ' ') {
            // Adiciona uma nova árvore na posição do jardineiro
            trees.push(createVector(jardineiro.x + 50, jardineiro.y - -15)); // Adiciona a posição da árvore
            arvoresPlantadas++; // Aumenta o contador de árvores
            temperatura -= 1; // Reduz a temperatura
        }
    }
}
